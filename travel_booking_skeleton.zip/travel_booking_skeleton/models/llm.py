# models/llm.py

from groq import Groq
import streamlit as st


def _get_creds():
    cfg = st.secrets.get("travelsim", {})
    api_key = cfg.get("api_key")
    model = cfg.get("model", "llama-3.1-8b-instant")
    if not api_key:
        raise RuntimeError("travelsim.api_key not set in .streamlit/secrets.toml")
    return api_key, model


def get_chatgroq_model():
    api_key, model = _get_creds()
    client = Groq(api_key=api_key)

    class GroqChatWrapper:
        def __init__(self, client, model):
            self.client = client
            self.model = model

        def invoke(self, messages):
            groq_msgs = []
            for m in messages:
                if hasattr(m, "type"):
                    role = m.type
                    if role == "human":
                        role = "user"
                    elif role == "ai":
                        role = "assistant"
                    content = m.content
                else:
                    role = m.get("role", "user")
                    content = m.get("content", "")
                groq_msgs.append({"role": role, "content": content})

            resp = self.client.chat.completions.create(
                model=self.model,
                messages=groq_msgs,
                temperature=0.2,
            )
            return resp.choices[0].message  # already a ChatCompletionMessage

    return GroqChatWrapper(client, model)


def chat_completion(prompt: str) -> str:
    """
    Simple helper used by RAG: given a prompt string, return a short answer.
    """
    api_key, model = _get_creds()
    client = Groq(api_key=api_key)
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a concise travel assistant. "
                    "Answer in 2–4 short sentences, directly addressing the question."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        temperature=0.2,
    )
    # resp.choices[0].message is a ChatCompletionMessage object, use .content
    return resp.choices[0].message.content
